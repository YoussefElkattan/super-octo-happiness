INSERT INTO booking(BookingID, BookingDate, TableNumber)
VALUES 
(1, '2022-10-10', 5),
(2, '2022-11-12', 3),
(3, '2022-10-11', 2),
(4, '2022-10-13', 2);